/**
* @author William Sun (wsun26)
*/

var gl;
var canvas;
var context; 
var shaderProgram;
var vertexPositionBuffer;

var days=0;

//Create a place to store terrain buffers for shading
var terrainPositionBuffer; 
var terrainNormalBuffer;
var terrainFaceBuffer;  
var terrainEdgeBuffer; 

// View parameters
var eyePt = vec3.fromValues(0.0,0.0,0.0);
var viewDir = vec3.fromValues(0.0,0.0,-1.0);
var up = vec3.fromValues(0.0,1.0,0.0);
var viewPt = vec3.fromValues(0.0,0.0,0.0);

// Create the normal
var nMatrix = mat3.create();

// Create ModelView matrix
var mvMatrix = mat4.create();

//Create Projection matrix
var pMatrix = mat4.create();

var mvMatrixStack = [];

var terrain_detail = 7; 
// Form quaternions for up/down and left/right
var UDQuat = quat.create(), RLQuat = quat.create(); 

// Set initial values for roll speed and air speed of plane
var turn_deg = 0.5; 
var scale_factor = 0.0; 
var y_eyePt = 0.0; 
var air_speed = 0.0005; 
var theta = 0; 
var rotateX = vec3.fromValues(Math.cos(degToRad(theta)), Math.sin(degToRad(theta)), 0.0); 

var uFog = 1; 

/**
 * Populates buffers with data for terrain with dimension n, where gridN = 2^n+1
 */
function setupTerrainBuffers(dimension) {
    var terrainHeight = new terrain(dimension); 
    terrainHeight.normalize(); 
    var terrainVertices = []; 
    var terrainFaces = []; 
    var terrainNormals = []; 
    var terrainEdges = []; 
    var numT = terrainFromIteration(terrainHeight.max, -1, 1, -1, 1, terrainVertices, terrainFaces, terrainNormals, terrainHeight);
    console.log("generated ", terrainVertices, "triangles"); 
    terrainNormals = setNorms(terrainFaces, terrainVertices, terrainNormals); 
    
    terrainPositionBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, terrainPositionBuffer);
	gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(terrainVertices), gl.STATIC_DRAW);
  	terrainPositionBuffer.itemSize = 3;
  	terrainPositionBuffer.numItems = (terrainHeight.size)*(terrainHeight.size);
    
  	terrainNormalBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, terrainNormalBuffer);
	gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(terrainNormals), gl.STATIC_DRAW);
	terrainNormalBuffer.itemSize = 3;
	terrainNormalBuffer.numItems = (terrainHeight.size)*(terrainHeight.size);  
    
  	terrainFaceBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, terrainFaceBuffer);
	gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(terrainFaces), gl.STATIC_DRAW);
	terrainFaceBuffer.itemSize = 1;
	terrainFaceBuffer.numItems = numT*3;  
 
  	generateLinesFromIndexedTriangles(terrainFaces, terrainEdges); 
    terrainEdgeBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, terrainEdgeBuffer);
	gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(terrainEdges), gl.STATIC_DRAW);
	terrainEdgeBuffer.itemSize = 1;
	terrainEdgeBuffer.numItems = terrainEdges.length;  
     
}

//-------------------------------------------------------------------------
/**
 * Draws a terrain from the terrain buffer
 */
function drawTerrain(){
 gl.polygonOffset(0, 0); 
 gl.bindBuffer(gl.ARRAY_BUFFER, terrainPositionBuffer);
 gl.vertexAttribPointer(shaderProgram.vertexPositionAttribute, terrainPositionBuffer.itemSize, 
                         gl.FLOAT, false, 0, 0);

 // Bind normal buffer
 gl.bindBuffer(gl.ARRAY_BUFFER, terrainNormalBuffer);
 gl.vertexAttribPointer(shaderProgram.vertexNormalAttribute, 
                           terrainNormalBuffer.itemSize,
                           gl.FLOAT, false, 0, 0);
    
 gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, terrainFaceBuffer);
 gl.drawElements(gl.TRIANGLES, terrainFaceBuffer.numItems, gl.UNSIGNED_SHORT, 0);      

}

//-------------------------------------------------------------------------
/**
 * Draws a terrain edges from the terrain edge buffer
 * don't actually use in submission
 */
function drawTerrainEdges(){
 gl.polygonOffset(1,1);
 gl.bindBuffer(gl.ARRAY_BUFFER, terrainPositionBuffer);
 gl.vertexAttribPointer(shaderProgram.vertexPositionAttribute, terrainPositionBuffer.itemSize,
                         gl.FLOAT, false, 0, 0);

 // Bind normal buffer
 gl.bindBuffer(gl.ARRAY_BUFFER, terrainNormalBuffer);
 gl.vertexAttribPointer(shaderProgram.vertexNormalAttribute,
                           terrainNormalBuffer.itemSize,
                           gl.FLOAT, false, 0, 0);

 //Draw
 gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, terrainEdgeBuffer);
 gl.drawElements(gl.LINES, terrainEdgeBuffer.numItems, gl.UNSIGNED_SHORT,0);
}


//-------------------------------------------------------------------------
/**
 * Sends Modelview matrix to shader
 */
function uploadModelViewMatrixToShader() {
  gl.uniformMatrix4fv(shaderProgram.mvMatrixUniform, false, mvMatrix);
}

//-------------------------------------------------------------------------
/**
 * Sends projection matrix to shader
 */
function uploadProjectionMatrixToShader() {
  gl.uniformMatrix4fv(shaderProgram.pMatrixUniform, 
                      false, pMatrix);
}

//-------------------------------------------------------------------------
/**
 * Generates and sends the normal matrix to the shader
 */
function uploadNormalMatrixToShader() {
  mat3.fromMat4(nMatrix,mvMatrix);
  mat3.transpose(nMatrix,nMatrix);
  mat3.invert(nMatrix,nMatrix);
  gl.uniformMatrix3fv(shaderProgram.nMatrixUniform, false, nMatrix);
}

//----------------------------------------------------------------------------------
/**
 * Pushes matrix onto modelview matrix stack
 */
function mvPushMatrix() {
    var copy = mat4.clone(mvMatrix);
    mvMatrixStack.push(copy);
}


//----------------------------------------------------------------------------------
/**
 * Pops matrix off of modelview matrix stack
 */
function mvPopMatrix() {
    if (mvMatrixStack.length == 0) {
      throw "Invalid popMatrix!";
    }
    mvMatrix = mvMatrixStack.pop();
}

//----------------------------------------------------------------------------------
/**
 * Sends projection/modelview matrices to shader
 */
function setMatrixUniforms() {
    uploadModelViewMatrixToShader();
    uploadNormalMatrixToShader();
    uploadProjectionMatrixToShader();
}

//----------------------------------------------------------------------------------
/**
 * Translates degrees to radians
 * @param {Number} degrees Degree input to function
 * @return {Number} The radians that correspond to the degree input
 */
function degToRad(degrees) {
        return degrees * Math.PI / 180;
}

//----------------------------------------------------------------------------------
/**
 * Creates a context for WebGL
 * @param {element} canvas WebGL canvas
 * @return {Object} WebGL context
 */
function createGLContext(canvas) {
  var names = ["webgl", "experimental-webgl"];
  var context = null;
  for (var i=0; i < names.length; i++) {
    try {
      context = canvas.getContext(names[i]);
    } catch(e) {}
    if (context) {
      break;
    }
  }
  if (context) {
    context.viewportWidth = canvas.width;
    context.viewportHeight = canvas.height;
  } else {
    alert("Failed to create WebGL context!");
  }
  return context;
}

//----------------------------------------------------------------------------------
/**
 * Loads Shaders
 * @param {string} id ID string for shader to load. Either vertex shader/fragment shader
 */
function loadShaderFromDOM(id) {
  var shaderScript = document.getElementById(id);
  
  // If we don't find an element with the specified id
  // we do an early exit 
  if (!shaderScript) {
    return null;
  }
  
  // Loop through the children for the found DOM element and
  // build up the shader source code as a string
  var shaderSource = "";
  var currentChild = shaderScript.firstChild;
  while (currentChild) {
    if (currentChild.nodeType == 3) { // 3 corresponds to TEXT_NODE
      shaderSource += currentChild.textContent;
    }
    currentChild = currentChild.nextSibling;
  }
 
  var shader;
  if (shaderScript.type == "x-shader/x-fragment") {
    shader = gl.createShader(gl.FRAGMENT_SHADER);
  } else if (shaderScript.type == "x-shader/x-vertex") {
    shader = gl.createShader(gl.VERTEX_SHADER);
  } else {
    return null;
  }
 
  gl.shaderSource(shader, shaderSource);
  gl.compileShader(shader);
 
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    alert(gl.getShaderInfoLog(shader));
    return null;
  } 
  return shader;
}

//----------------------------------------------------------------------------------
/**
 * Setup the fragment and vertex shaders
 */
function setupShaders() {
  vertexShader = loadShaderFromDOM("shader-vs");
  fragmentShader = loadShaderFromDOM("shader-fs");
  
  shaderProgram = gl.createProgram();
  gl.attachShader(shaderProgram, vertexShader);
  gl.attachShader(shaderProgram, fragmentShader);
  gl.linkProgram(shaderProgram);

  if (!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)) {
    alert("Failed to setup shaders");
  }

  gl.useProgram(shaderProgram);

  shaderProgram.vertexPositionAttribute = gl.getAttribLocation(shaderProgram, "aVertexPosition");
  gl.enableVertexAttribArray(shaderProgram.vertexPositionAttribute);

  shaderProgram.vertexNormalAttribute = gl.getAttribLocation(shaderProgram, "aVertexNormal");
  gl.enableVertexAttribArray(shaderProgram.vertexNormalAttribute);

  shaderProgram.mvMatrixUniform = gl.getUniformLocation(shaderProgram, "uMVMatrix");
  shaderProgram.pMatrixUniform = gl.getUniformLocation(shaderProgram, "uPMatrix");
  shaderProgram.nMatrixUniform = gl.getUniformLocation(shaderProgram, "uNMatrix");
  shaderProgram.uniformLightPositionLoc = gl.getUniformLocation(shaderProgram, "uLightPosition");    
  shaderProgram.uniformAmbientLightColorLoc = gl.getUniformLocation(shaderProgram, "uAmbientLightColor");  
  shaderProgram.uniformDiffuseLightColorLoc = gl.getUniformLocation(shaderProgram, "uDiffuseLightColor");
  shaderProgram.uniformSpecularLightColorLoc = gl.getUniformLocation(shaderProgram, "uSpecularLightColor");
 
  // Implement fog shader
  shaderProgram.uniformFog  = gl.getUniformLocation(shaderProgram, "uFog"); 
}

//-------------------------------------------------------------------------
/**
 * Sends material information to the shader
 * @param {Float32Array} a diffuse material color
 * @param {Float32Array} a ambient material color
 * @param {Float32Array} a specular material color 
 * @param {Float32} the shininess exponent for Phong illumination
 */
function uploadMaterialToShader(dcolor, acolor, scolor,shiny) {
  gl.uniform3fv(shaderProgram.uniformDiffuseMaterialColor, dcolor);
  gl.uniform3fv(shaderProgram.uniformAmbientMaterialColor, acolor);
  gl.uniform3fv(shaderProgram.uniformSpecularMaterialColor, scolor);
    
}

//-------------------------------------------------------------------------
/**
 * Sends light information to the shader
 * @param {Float32Array} loc Location of light source
 * @param {Float32Array} a Ambient light strength
 * @param {Float32Array} d Diffuse light strength
 * @param {Float32Array} s Specular light strength
 */
function uploadLightsToShader(loc,a,d,s) {
  gl.uniform3fv(shaderProgram.uniformLightPositionLoc, loc);
  gl.uniform3fv(shaderProgram.uniformAmbientLightColorLoc, a);
  gl.uniform3fv(shaderProgram.uniformDiffuseLightColorLoc, d);
  gl.uniform3fv(shaderProgram.uniformSpecularLightColorLoc, s); 

  // Upload fog shader
  gl.uniform1f(shaderProgram.uniformFog, uFog);
}

//----------------------------------------------------------------------------------
/**
 * Populate buffers with data
 * terrain buffer set to n=6 for 2^n+1 grid size
 */
function setupBuffers() {
    setupTerrainBuffers(terrain_detail); 
    //setupSphereBuffers();     
}

//----------------------------------------------------------------------------------
/**
 * Draw call that applies matrix transformations to model and draws model in frame
 */
function draw() { 
    var transformVec = vec3.create();
  
    gl.viewport(0, 0, gl.viewportWidth, gl.viewportHeight);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    // We'll use perspective 
    mat4.perspective(pMatrix,degToRad(45), gl.viewportWidth / gl.viewportHeight, 0.1, 200.0);

    // We want to look down -z, so create a lookat point in that direction    
    vec3.add(viewPt, eyePt, viewDir);
    // Then generate the lookat matrix and initialize the MV matrix to that view
    mat4.lookAt(mvMatrix,eyePt,viewPt,up);    
 
    //Draw Terrain
    mvPushMatrix();
    vec3.set(transformVec,0.0,-0.25,-4.0);
    mat4.translate(mvMatrix, mvMatrix,transformVec);
    mat4.rotateX(mvMatrix, mvMatrix, degToRad(-50));
    mat4.rotateZ(mvMatrix, mvMatrix, degToRad(45));     
    setMatrixUniforms();
    
    
    uploadLightsToShader([0,1,1],[0.0,0,0],[0.0,0.5,0.8],[0.0,0,0]);
    drawTerrain(); 
    mvPopMatrix();
  
}

//----------------------------------------------------------------------------------
/**
 * Animation to be called from tick. Updates globals and performs animation for each tick.
 * not used currently
 */
function animate() {
    scale_factor -= air_speed; 
    eyePt = vec3.fromValues(eyePt[0], y_eyePt, scale_factor); 
}

//----------------------------------------------------------------------------------
/**
 * Startup function called from html code to start program.
 */
 function startup() {
  canvas = document.getElementById("myGLCanvas"); 
  // Start onKeyDown() when key is pressed
  window.addEventListener('keydown', onKeyDown, false); 
  // Start restart() when mouse is clicked
  window.addEventListener('mouseup', restart); 
  gl = createGLContext(canvas);
  setupShaders(); 
  setupBuffers();
  gl.clearColor(0.0, 0.86, 1.0, 1.0);
  gl.enable(gl.DEPTH_TEST);
  tick(); 
}

//----------------------------------------------------------------------------------
/**
 * Tick called for every animation frame.
 */
function tick() {
    requestAnimFrame(tick);
    animate();
    draw();
}

//----------------------------------------------------------------------------------
/**
 * Function for keydown events, such as up/down/left/right/+/-/spacebar
 */
function onKeyDown(event){
    rotateX = vec3.fromValues(Math.cos(degToRad(theta)), -Math.sin(degToRad(theta)), 0.0); 
    if(event.keyCode == "70"){
        uFog = !uFog; 
    }
    if(event.keyCode == "37"){
        quat.setAxisAngle(RLQuat, viewDir, degToRad(-turn_deg*2)); 
        theta -= turn_deg*2; 
        vec3.transformQuat(up, up, RLQuat); 
    }
    if(event.keyCode == "39"){
        quat.setAxisAngle(RLQuat, viewDir, degToRad(turn_deg*2));
        theta += turn_deg*2; 
        vec3.transformQuat(up, up, RLQuat); 
    }
	if(event.keyCode == "38"){
		//y_eyePt += 0.02; 
		//eyePt[1] = y_eyePt; 
		quat.setAxisAngle(UDQuat, rotateX, degToRad(-turn_deg)); 
		vec3.transformQuat(viewDir, viewDir, UDQuat); 
		//vec3.transformQuat(up, up, UDQuat); 
	}
	if(event.keyCode == "40"){
		//y_eyePt -= 0.02; 
		//eyePt[1] = y_eyePt; 
		quat.setAxisAngle(UDQuat, rotateX, degToRad(turn_deg)); 
		vec3.transformQuat(viewDir, viewDir, UDQuat); 
		//vec3.transformQuat(up, up, UDQuat); 
	}
	if(event.keyCode == "187"){
		air_speed *= 2; 
	}
	if(event.keyCode == "189"){
		air_speed /= 2; 
	}
}

//----------------------------------------------------------------------------------
/**
 * Restart function to redraw terrain
 */
function restart(){
    terrain_detail = document.getElementById("terrain_detail").value;
    gl.clear(gl.COLOR_BUFFER_BIT); 
    startup(); 
}